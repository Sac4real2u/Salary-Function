# Employee Sales Data Pipeline & Analysis

This project features a dual-language implementation (Python and R) to search, process, export, and read specific employee sales records.

## Project Structure
- `employee_report.csv`: Source dataset containing raw employee performance rows.
- `Salary Function Assign 2.py`: Python script containing search, processing, and data extraction functions.
- `Salary Function Assign 2.R`: R script used to safely extract and display target report data.

---

## 🚀 How to Run the Python Code
The Python script extracts single employee entries and safely appends them into an existing zip directory without modifying other contents.

### Prerequisites
Ensure you have Python 3.x installed. No third-party libraries are required as it uses standard modules (`csv`, `zipfile`, `io`, `os`).

### Execution
Run the following command in your terminal or execute the blocks within your Jupyter Notebook cell:
```bash
python Salary Function Assign 2.py
```

---

## 📊 How to Run the R Code
The R script reads the archived reporting metrics directly from the compressed folder safely via automated text parsing.

### Prerequisites
Ensure **R** or **RStudio** is installed.

### Execution
Open your R console or environment and execute:
```R
source("Salary Function Assign 2.R")
```
