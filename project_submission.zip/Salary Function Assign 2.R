
# --- 1. SET WORKING DIRECTORY & DEFINE PATHS ---
# This ensures R looks in the exact folder where your files are
# Change this path to where your 'my_detail.zip' is physically located
# setwd("C:/Users/YourName/Documents") 

zip_path <- "C:/Users/Samuel/Employee Profile.zip"

# --- 2. DIAGNOSTIC CHECK 1: DOES THE ZIP FILE EXIST? ---
if (!file.exists(zip_path)) {
  stop(paste("CRITICAL ERROR: The file '", zip_path, "' was not found in your current working directory (", getwd(), "). Move the zip folder here or use setwd() to point to it.", sep=""))
}

# --- 3. DIAGNOSTIC CHECK 2: WHAT IS INSIDE THE ZIP? ---
files_list <- unzip(zip_path, list = TRUE)

if (nrow(files_list) == 0) {
  stop("CRITICAL ERROR: The zip archive exists, but it is completely empty.")
}

print("--- FILES FOUND INSIDE THE ZIP ---")
print(files_list)

# Find the first file inside the zip that ends with '.csv'
target_csv <- files_list$Name[grep("\\.csv$", files_list$Name)][1]

if (is.na(target_csv)) {
  stop("CRITICAL ERROR: There are no files ending in '.csv' inside this zip archive.")
}

# --- 4. SAFE EXTRACTION AND DISPLAY ---
tryCatch({
  # Unzip to a temporary directory to bypass lock/permission issues
  temp_dir <- tempdir()
  unzip(zip_path, files = target_csv, exdir = temp_dir)
  
  # Construct full file path
  full_csv_path <- file.path(temp_dir, target_csv)
  
  # Read the CSV data
  employee_data <- read.csv(full_csv_path, stringsAsFactors = FALSE, check.names = FALSE)
  
  # Display data to console
  cat("\n=== SUCCESS: EMPLOYEE DATA DISPLAYED BELOW ===\n")
  print(employee_data)
  
}, error = function(e) {
  cat("\nAn unexpected error occurred during execution:\n")
  print(e)
})
