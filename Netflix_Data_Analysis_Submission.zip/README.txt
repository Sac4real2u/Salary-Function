# Netflix Portfolio Data Analysis Project Submission

An end-to-end framework leveraging combined Python/R stacks to extract, audit, clean, evaluate, and chart Netflix video properties.

## Execution Sequence

### Phase 1: Python Pipeline Execution
Run the data cleaning script to unzip the target file, repair missing dataset rows, produce analytical descriptions, and compile charts:
```bash
pip install pandas matplotlib seaborn
python data_analysis.py
```
*Outputs generated:* `ratings_distribution_python.png`, `top_genres_python.png`, and a processed structural table artifact at `Netflix_shows_movies/cleaned_netflix_data.csv`.

### Phase 2: R Studio / Environment Visualization Execution
Generate equivalent visualization graphics to demonstrate seamless multi-language pipeline consistency:
```bash
Rscript r_visualization.R
```
*Outputs generated:* `ratings_distribution_r.png` (built using `ggplot2`).
