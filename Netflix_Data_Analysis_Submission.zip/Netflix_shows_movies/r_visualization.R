# r_visualization.R

# Step 1: Automatically install and load ggplot2 if not already present
if (!require("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2", repos = "http://r-project.org")
}
library(ggplot2)

# Step 2: Establish the absolute Windows path for the Downloads directory
user_home <- Sys.getenv("USERPROFILE")
downloads_dir <- file.path(user_home, "Downloads", "Netflix_shows_movies")
target_csv <- file.path(downloads_dir, "cleaned_netflix_data.csv")

# Fallback check for current local directory execution
if (!file.exists(target_csv)) {
  target_csv <- "Netflix_shows_movies/cleaned_netflix_data.csv"
}

if (file.exists(target_csv)) {
  cat("Successfully found clean dataset at:", target_csv, "\n")
  netflix_df <- read.csv(target_csv, stringsAsFactors = FALSE)
  
  # Step 3: Render Content Rating Category counts using ggplot2
  rating_plot <- ggplot(netflix_df, aes(x = factor(rating, levels = names(sort(table(rating), decreasing = TRUE))))) +
    geom_bar(fill = "#E50914", color = "black", alpha = 0.85) + # Netflix Corporate Red Palette
    theme_minimal() +
    labs(
      title = "Netflix Ratings Profile Distribution (R Integration Engine)",
      x = "Assigned Advisory Rating Group",
      y = "Total Registered Volume"
    ) +
    theme(
      plot.title = element_text(face = "bold", size = 13, hjust = 0.5),
      axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
      panel.grid.minor = element_blank()
    )
  
  # Step 4: Export the crisp plot artifact inside the same directory
  output_image <- file.path(downloads_dir, "ratings_distribution_r.png")
  ggsave(output_image, plot = rating_plot, width = 10, height = 6, dpi = 300)
  cat("Success: Produced and saved 'ratings_distribution_r.png' at:", output_image, "\n")
  
} else {
  cat("Execution Blocked: Cannot find 'cleaned_netflix_data.csv' in standard Windows directories.\n")
  cat("Please ensure you have run the data_analysis.py Python script completely first.\n")
}
