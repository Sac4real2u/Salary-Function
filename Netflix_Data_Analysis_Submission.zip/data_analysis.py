# data_analysis.py
import os
import zipfile
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def main():
    print("--- Step 1: Data Preparation ---")
    # Dynamically locate the zip folder inside the local user downloads environment
    zip_path = os.path.expanduser('~/Downloads/Netflix_data.zip')
    extract_dir = 'Netflix_shows_movies'
    
    # Context fallback if local path setup differs
    if not os.path.exists(zip_path):
        zip_path = 'netflix_data.zip'
        
    if os.path.exists(zip_path):
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        print(f"Dataset successfully unzipped to target folder: '{extract_dir}'")
    else:
        print(f"Error: Target archive missing at location: {zip_path}")
        return

    # Identify extracted .csv inside target destination
    csv_file = None
    for file in os.listdir(extract_dir):
        if file.endswith('.csv'):
            csv_file = os.path.join(extract_dir, file)
            break
            
    if not csv_file:
        print("Pipeline Stopped: No CSV found within extraction path.")
        return

    df = pd.read_csv(csv_file)
    print(f"Dataset loaded. Initial Structure: {df.shape[0]} rows, {df.shape[1]} columns.")

    print("\n--- Step 2: Data Cleaning & Imputation ---")
    print("Initial Null Values Encountered:")
    print(df.isnull().sum())
    
    # Standardize data elements by resolving incomplete features without deleting records
    df['director'] = df['director'].fillna('Unknown Director')
    df['cast'] = df['cast'].fillna('Unknown Cast')
    df['country'] = df['country'].fillna(df['country'].mode()[0] if not df['country'].mode().empty else 'United States')
    df['rating'] = df['rating'].fillna('NR')  # Default to No Rating
    df['date_added'] = df['date_added'].fillna('January 1, 2021')
    
    print("Cleaned Missing Structural Data Check:")
    print(df.isnull().sum())

    print("\n--- Step 3: Statistical Data Exploration ---")
    print(df.describe(include='all'))
    print("\nDistribution Breakdown of Show Type:")
    print(df['type'].value_counts())
        

    print("\n--- Step 4: Python Data Visualizations ---")
    sns.set_theme(style="whitegrid")
    
    # Visualization A: Ratings Categorical Distribution Chart    
    plt.figure(figsize=(10, 6))
    
    sns.countplot(
        data=df, 
        x='rating', 
        order=df['rating'].value_counts().index, 
        hue='rating', 
        legend=False, 
        palette='tab20'
    )
    
    plt.title('Netflix Content Distribution Across Rating Types', fontsize=15, fontweight='bold')
    plt.xlabel('Rating Standard', fontsize=12)
    plt.ylabel('Asset Counts', fontsize=12)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    plt.savefig('ratings_distribution_python.png')
    plt.show()
    plt.close()
    print("Rendered and exported 'ratings_distribution_python.png'")

    # Visualization B: Most Watched & Listed Genres (Unpacking comma-separated arrays)
    genres_series = df['listed_in'].dropna().str.split(', ')
    exploded_genres = genres_series.explode()
    
    # FIXED: Reset the index and convert to a DataFrame to resolve duplicate key errors
    genres_df = exploded_genres.reset_index(drop=True).to_frame(name='Genre')
    
    plt.figure(figsize=(12, 6))
    
    sns.countplot(
        data=genres_df,
        y='Genre', 
        order=genres_df['Genre'].value_counts().index[:10], 
        hue='Genre',
        legend=False,
        palette='viridis'
    )
    
    plt.title('Top 10 Most Listed Genres on Netflix', fontsize=15, fontweight='bold')
    plt.xlabel('Count of Catalog Titles', fontsize=12)
    plt.ylabel('Genre Category', fontsize=12)
    plt.tight_layout()
    
    plt.savefig('top_genres_python.png')
    plt.show()
    plt.close()
    print("Rendered and exported 'top_genres_python.png'")
    
    # Save a cross-platform data snapshot for the R engine environment
    cleaned_export = os.path.join(extract_dir, 'cleaned_netflix_data.csv')
    df.to_csv(cleaned_export, index=False)
    print(f"Data hand-off saved to: {cleaned_export}")

if __name__ == '__main__':
    main()
