
# ==========================================
# 1. PRODUCT CLASS DEFINITION
# ==========================================
class Product:
    def __init__(self, product_id, name, price, status="Active"):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.status = status  # Options: "Active" or "Suspended"

    def update_product(self, name=None, price=None):
        # "Updates the product name or price details.
        if name:
            self.name = name
        if price:
            self.price = price
        print(f"Product {self.product_id} updated: {self.name} (${self.price})")

    def suspend_product(self):
        # Suspends the product to prevent new policyholders from signing up.
        self.status = "Suspended"
        print(f"Product '{self.name}' has been suspended.")

    def reactivate_product(self):
        # Reactivates the product for new registrations.
        self.status = "Active"
        print(f"Product '{self.name}' has been reactivated.")

# ==========================================
# 2. POLICYHOLDER CLASS DEFINITION
# ==========================================
class Policyholder:
    def __init__(self, holder_id, name, email):
        self.holder_id = holder_id
        self.name = name
        self.email = email
        self.status = "Active"  # Options: "Active" or "Suspended"
        self.products = []      # Holds active registered insurance products

    def register_product(self, product):
        # Registers a product if both the policyholder and product are active.
        if self.status == "Active" and product.status == "Active":
            self.products.append(product)
            print(f"Successfully registered '{product.name}' for {self.name}.")
        else:
            print(f"Registration failed for {self.name}. Check account or product status.")

    def suspend_holder(self):
        # Suspends the policyholder's account profile.
        self.status = "Suspended"
        print(f"Policyholder account for {self.name} has been suspended.")

    def reactivate_holder(self):
        # Reactivates a suspended policyholder account profile.
        self.status = "Active"
        print(f"Policyholder account for {self.name} has been reactivated.")

    def display_details(self):
        # Prints a comprehensive breakdown of the policyholder account profile.
        print("\n" + "="*40)
        print(f"POLICYHOLDER PROFILE: {self.name}")
        print("="*40)
        print(f"ID: {self.holder_id}")
        print(f"Email: {self.email}")
        print(f"Account Status: {self.status}")
        print("Registered Products:")
        if not self.products:
            print(" - No active products associated with this account.")
        for product in self.products:
            print(f" - {product.name} (Premium cost: ${product.price:.2f})")
        print("="*40 + "\n")

# ==========================================
# 3. PAYMENT CLASS DEFINITION
# ==========================================
class Payment:
    def __init__(self, payment_id, policyholder, product):
        self.payment_id = payment_id
        self.policyholder = policyholder
        self.product = product
        self.amount_paid = 0.0
        self.status = "Pending"  # Options: "Pending", "Paid", or "Penalized"

    def process_payment(self, amount):
        # Validates if the paid amount matches the product price to clear the balance.
        if amount >= self.product.price:
            self.amount_paid = amount
            self.status = "Paid"
            print(f"Payment of ${amount:.2f} processed for {self.policyholder.name} ({self.product.name}).")
        else:
            print(f"Payment failed. ${amount:.2f} is insufficient for product price (${self.product.price:.2f}).")

    def send_reminder(self):
        # Sends an notification alert message for unpaid account balances.
        if self.status == "Pending":
            print(f"REMINDER sent to {self.policyholder.email}: Payment for '{self.product.name}' is overdue.")

    def apply_penalty(self, penalty_amount):
        # Applies a fine penalty to the account for overdue balances.
        if self.status == "Pending":
            self.status = "Penalized"
            print(f"PENALTY: ${penalty_amount:.2f} fine applied to {self.policyholder.name} for non-payment.")

# ==========================================
# 4. EXECUTION FLOW (MAIN)
# ==========================================
def run_demonstration():
    print("--- SYSTEM INITIALIZATION ---\n")

    # 1. Create separate insurance products
    health_insurance = Product(product_id="P501", name="Premium Health Plan", price=120.00)
    auto_insurance = Product(product_id="P502", name="Comprehensive Auto Plan", price=250.00)

    # 2. Register two distinct policyholders
    client1 = Policyholder(holder_id="H101", name="Alice Smith", email="alice.smith@example.com")
    client2 = Policyholder(holder_id="H102", name="Bob Jones", email="bob.jones@example.com")

    # 3. Simulate processing for Policyholder 1
    client1.register_product(health_insurance)
    bill1 = Payment(payment_id="TXN001", policyholder=client1, product=health_insurance)
    bill1.process_payment(120.00)

    # 4. Simulate processing for Policyholder 2
    client2.register_product(auto_insurance)
    bill2 = Payment(payment_id="TXN002", policyholder=client2, product=auto_insurance)
    bill2.process_payment(250.00)

    # 5. Display the final account profiles
    print("\n--- ACCOUNT DEMONSTRATION RECORDS ---")
    client1.display_details()
    client2.display_details()

if __name__ == "__main__":
    run_demonstration()