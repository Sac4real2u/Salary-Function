

class Product:
    def __init__(self, product_id, name, price, status="Active"):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.status = status  # Options: "Active" or "Suspended"

    def update_product(self, name=None, price=None):
        # "Updates the product name or price details.
        if name:
            self.name = name
        if price:
            self.price = price
        print(f"Product {self.product_id} updated: {self.name} (${self.price})")

    def suspend_product(self):
        # Suspends the product to prevent new policyholders from signing up.
        self.status = "Suspended"
        print(f"Product '{self.name}' has been suspended.")

    def reactivate_product(self):
        # Reactivates the product for new registrations.
        self.status = "Active"
        print(f"Product '{self.name}' has been reactivated.")