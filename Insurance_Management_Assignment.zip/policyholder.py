
class Policyholder:
    def __init__(self, holder_id, name, email):
        self.holder_id = holder_id
        self.name = name
        self.email = email
        self.status = "Active"  # Options: "Active" or "Suspended"
        self.products = []      # Holds active registered insurance products

    def register_product(self, product):
        # Registers a product if both the policyholder and product are active.
        if self.status == "Active" and product.status == "Active":
            self.products.append(product)
            print(f"Successfully registered '{product.name}' for {self.name}.")
        else:
            print(f"Registration failed for {self.name}. Check account or product status.")

    def suspend_holder(self):
        # Suspends the policyholder's account profile.
        self.status = "Suspended"
        print(f"Policyholder account for {self.name} has been suspended.")

    def reactivate_holder(self):
        # Reactivates a suspended policyholder account profile.
        self.status = "Active"
        print(f"Policyholder account for {self.name} has been reactivated.")

    def display_details(self):
        # Prints a comprehensive breakdown of the policyholder account profile.
        print("\n" + "="*40)
        print(f"POLICYHOLDER PROFILE: {self.name}")
        print("="*40)
        print(f"ID: {self.holder_id}")
        print(f"Email: {self.email}")
        print(f"Account Status: {self.status}")
        print("Registered Products:")
        if not self.products:
            print(" - No active products associated with this account.")
        for product in self.products:
            print(f" - {product.name} (Premium cost: ${product.price:.2f})")
        print("="*40 + "\n")