
from product import Product
from policyholder import Policyholder
from payment import Payment

def run_demonstration():
    print("--- SYSTEM INITIALIZATION ---\n")

    # 1. Create separate insurance products
    health_insurance = Product(product_id="P501", name="Premium Health Plan", price=120.00)
    auto_insurance = Product(product_id="P502", name="Comprehensive Auto Plan", price=250.00)

    # 2. Register two distinct policyholders
    client1 = Policyholder(holder_id="H101", name="Alice Smith", email="alice.smith@example.com")
    client2 = Policyholder(holder_id="H102", name="Bob Jones", email="bob.jones@example.com")

    # 3. Simulate processing for Policyholder 1
    client1.register_product(health_insurance)
    bill1 = Payment(payment_id="TXN001", policyholder=client1, product=health_insurance)
    bill1.process_payment(120.00)

    # 4. Simulate processing for Policyholder 2
    client2.register_product(auto_insurance)
    bill2 = Payment(payment_id="TXN002", policyholder=client2, product=auto_insurance)
    bill2.process_payment(250.00)

    # 5. Display the final account profiles
    print("\n--- ACCOUNT DEMONSTRATION RECORDS ---")
    client1.display_details()
    client2.display_details()

if __name__ == "__main__":
    run_demonstration()