# Insurance Management System

An Object-Oriented Programming (OOP) application written in Python to manage policyholder records, insurance products, and contract payment workflows.

## File Structure
The project uses strict separation of concerns across the following modular files:
* `product.py` - Houses the `Product` class to modify or suspend insurance plans.
* `policyholder.py` - Houses the `Policyholder` class to manage customer accounts and registrations.
* `payment.py` - Houses the `Payment` class to process financial bills, penalties, and alerts.
* `main.py` - Executable testing script simulating two accounts purchasing active products.
* `test_policy_system.py` - Executable the full testing script with all class(product,policyholder,payment) simulating two accounts purchasing active products.

## How to Run the Code
1. Ensure **Python 3.x** is installed on your local environment terminal.
2. Clone this repository or extract the submission zip file into an empty folder.
3. Open a command prompt or terminal shell inside that project directory.
4. Run the demo application by entering the following command:
   ```bash
   python main.py
   ```
