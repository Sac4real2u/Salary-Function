
class Payment:
    def __init__(self, payment_id, policyholder, product):
        self.payment_id = payment_id
        self.policyholder = policyholder
        self.product = product
        self.amount_paid = 0.0
        self.status = "Pending"  # Options: "Pending", "Paid", or "Penalized"

    def process_payment(self, amount):
        # Validates if the paid amount matches the product price to clear the balance.
        if amount >= self.product.price:
            self.amount_paid = amount
            self.status = "Paid"
            print(f"Payment of ${amount:.2f} processed for {self.policyholder.name} ({self.product.name}).")
        else:
            print(f"Payment failed. ${amount:.2f} is insufficient for product price (${self.product.price:.2f}).")

    def send_reminder(self):
        # Sends an notification alert message for unpaid account balances.
        if self.status == "Pending":
            print(f"REMINDER sent to {self.policyholder.email}: Payment for '{self.product.name}' is overdue.")

    def apply_penalty(self, penalty_amount):
        # Applies a fine penalty to the account for overdue balances.
        if self.status == "Pending":
            self.status = "Penalized"
            print(f"PENALTY: ${penalty_amount:.2f} fine applied to {self.policyholder.name} for non-payment.")