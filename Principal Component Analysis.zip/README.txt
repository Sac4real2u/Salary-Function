# Anderson Cancer Center - Referral Optimization Model Using PCA

This repository contains a data analytics solution developed to manage the increasing volume of patient referrals at the Anderson Cancer Center. By condensing complex clinical variables into critical insights, this model serves as an essential framework to justify and secure donor funding. 

We utilize **Principal Component Analysis (PCA)** to reduce the dimension of the dataset down to two critical components, followed by a **Logistic Regression** model to demonstrate clinical predictive utility.

## Project Structure
* `pca_analysis.py` - The core Python script containing data pipeline, PCA execution, and predictive modeling.
* `pca_visualization.png` - A high-resolution scatter plot showcasing the variance separation between malignant and benign cases.
* `README.md` - Comprehensive documentation and execution manual (this file).

## Prerequisites
Before launching the script, guarantee that Python 3.x is configured on your machine and install the required dependencies:

```bash
pip install numpy pandas scikit-learn matplotlib seaborn
```

## How to Execute the Project
1. Download this directory as a `.zip` archive or clone the repository via Git.
2. Open your terminal, command line interface, or bash shell inside the project folder.
3. Run the application script using the command:
```bash
python pca_analysis.py
```

## Key Findings & Project Insights
* **Dimensionality Reduction:** The model successfully condenses 30 comprehensive dimensional data features into just **2 Principal Components** while retaining a substantial percentage of the underlying informational variance (approx ~63%).
* **Donor Funding Utility:** Presenting data via 2 components provides clean, visual clarity for non-technical stakeholders (donors) to understand classification distributions easily.
* **Model Accuracy (Bonus):** Training a Logistic Regression model on top of these 2 abstract components produces an impressive evaluation classification accuracy score exceeding **95%**.
