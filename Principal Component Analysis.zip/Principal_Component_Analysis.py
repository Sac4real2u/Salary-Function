
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# ---------------------------------------------------------
# Step 1: Load and Preprocess the Dataset
# ---------------------------------------------------------
# Load the breast cancer dataset from sklearn
cancer_data = load_breast_cancer()
X = pd.DataFrame(cancer_data.data, columns=cancer_data.feature_names)
y = cancer_data.target

# PCA is sensitive to variances, so data standardization is mandatory
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ---------------------------------------------------------
# Step 2: Implement PCA (Dimensionality Reduction)
# ---------------------------------------------------------
# Reduce the 30 features into 2 primary PCA components
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# Convert the principal components into a structured DataFrame
pca_df = pd.DataFrame(data=X_pca, columns=['Principal Component 1', 'Principal Component 2'])
pca_df['Target'] = y

# Calculate and display the explained variance ratio
evr = pca.explained_variance_ratio_
print("=== PCA VARIANCE SUMMARY ===")
print(f"Variance explained by PC1: {evr[0]*100:.2f}%")
print(f"Variance explained by PC2: {evr[1]*100:.2f}%")
print(f"Total Cumulative Variance Retained: {np.sum(evr)*100:.2f}%\n")

# ---------------------------------------------------------
# Step 3: Bonus Task - Logistic Regression Prediction
# ---------------------------------------------------------
# Split the PCA-reduced dataset into Training (70%) and Testing (30%) sets
X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=0.3, random_state=42, stratify=y)

# Initialize and train the Logistic Regression model
log_reg = LogisticRegression()
log_reg.fit(X_train, y_train)

# Generate predictions on the test partition
y_pred = log_reg.predict(X_test)

# Evaluate and print model performance metrics
print("=== LOGISTIC REGRESSION PERFORMANCE ===")
print(f"Prediction Accuracy Score: {accuracy_score(y_test, y_pred)*100:.2f}%\n")
print("Classification Report:")
print(classification_report(y_test, y_pred, target_names=cancer_data.target_names))

# ---------------------------------------------------------
# Step 4: Visualization (Data Plotting)
# ---------------------------------------------------------
plt.figure(figsize=(10, 7))
sns.scatterplot(x='Principal Component 1', y='Principal Component 2', hue='Target', data=pca_df, palette='Set1', alpha=0.7)
plt.title('PCA - Anderson Cancer Center Referral Model')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.legend(labels=['Malignant', 'Benign'])
plt.grid(True)

# Save the visualization to disk
plt.savefig('pca_visualization.png')
print("PCA cluster visualization plot saved as 'pca_visualization.png'")